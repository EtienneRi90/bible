const CACHE_NAME = 'bibiliya-nyeranda-v2';

// Core files needed for the app to work fully offline in Kirundi, French, and English.
const PRECACHE_URLS = [
  './',
  './index.html',
  './manifest.json',
  './bible-data.json',
  './bible-data-fr.json',
  './bible-data-en.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Only handle GET requests
  if (event.request.method !== 'GET') return;

  const isSameOrigin = url.origin === self.location.origin;

  if (isSameOrigin) {
    // App shell and bundled Bible data: cache-first, so the app opens instantly
    // and works fully offline once visited once.
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;
        return fetch(event.request).then((response) => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          return response;
        });
      })
    );
  } else {
    // English (thedouayrheims.com) and anything else external: network-first,
    // falling back to cache when offline. Successful responses are cached so
    // a book read once in English becomes available offline afterward too.
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          return response;
        })
        .catch(() => caches.match(event.request))
    );
  }
});
