# Bibiliya Nyeranda — Trilingual Web Reader

A searchable, static Bible-reading web app in **Kirundi, English, and French**
— all 73 Catholic canon books, with a language switcher at the top of the page.

## Deploying to Netlify

1. Go to [app.netlify.com](https://app.netlify.com) and log in.
2. Drag the whole `bible-app` folder (containing `index.html`, `bible-data.json`,
   and `bible-data-fr.json`) onto the Netlify dashboard.
3. Done — no build step. Netlify gives you a live URL immediately.

All files must stay in the same folder — `index.html` loads the two JSON
files by relative path.

## How the three languages work

- **Kirundi** — bundled in `bible-data.json`, loads instantly, no internet
  dependency beyond the initial page load.
- **French** — bundled in `bible-data-fr.json` (Bible Crampon, 1923, complete
  Catholic edition including the deuterocanon), same instant loading.
- **English** — fetched live, one book at a time, from the free public-domain
  Douay-Rheims Bible API (`thedouayrheims.com`) the first time a person opens
  that book in English. After that it's cached in the browser tab for the
  rest of the session. This means English requires an internet connection at
  read-time (Kirundi and French do not) — if `thedouayrheims.com` is ever
  down or the person is offline, English simply won't load for that visit,
  while Kirundi and French keep working normally.

Search matches the Kirundi, English, or French *name* of a book regardless
of which language is currently selected for reading — so typing "Genèse"
finds Genesis even while you're reading in Kirundi.

## Data quality — please read before wide distribution

### Kirundi (Bibiliya Nyeranda)
See the original data-quality notes below — the short version: all 73 books
verified, chapter numbering verified for 70 of 73 books, three books
(Ihunguka/Exodus, Iharura/Numbers, Samweli wa Kabiri/2 Samuel) flagged with a
visible badge in the app pending a manual read-through.

### French (Bible Crampon, 1923)
Extracted from a cleanly-typeset PDF (not scanned), and it shows: **all 73
books matched their expected chapter count on the first pass, with zero
discrepancies.** I additionally spot-checked real verses across the whole
canon — Genesis 1, John 3:16, Romans 8:28, Tobit 1:1, Wisdom 1:1, Sirach,
and Revelation's closing verse — and all read correctly. This is the
strongest of the three datasets.

One legitimate, expected difference: **Esther has 16 chapters** in this
edition rather than 10, because this Catholic edition presents the Greek
additions as their own chapters instead of folding them into the Hebrew
chapters — this is a known, valid convention difference, not an error, and
is why Esther's chapter count differs between the Kirundi and French
versions in the app.

A small number of individual verses (roughly 1 in 500) may have a stray
trailing number or minor merge at a page-break boundary; I ran a cleanup
pass for the most common pattern (trailing page numbers), but a few may
remain. This does not affect chapter or book numbering, only occasional
verse-text tidiness.

### English (Douay-Rheims, via thedouayrheims.com)
Not built by me — this is an existing, actively maintained, CC0 public-domain
dataset. I'm not able to vouch for its accuracy personally, but it comes
from a dedicated project with structured JSON/USFM output and its own
documented QA (see thedouayrheims.com/download). Trustworthy by reputation
and source, not independently verified by this project.

**My recommendation before public launch:** the French and Kirundi data are
in good shape to share now. If you want extra confidence, a native
French-speaking proofreader skimming a chapter or two across a few random
books would be the fastest way to build additional trust, given how clean
the extraction came out.

## Regenerating or extending the data

If you get updated or corrected source PDFs later, the same approach
applies for any of the three: extract text, locate book boundaries by
title, locate chapter boundaries by an explicit "Chapitre N" / "Psaume N"
label (French) or by the "verse 1 preceded by a blank line" pattern
(Kirundi), then split verses positionally within each confirmed chapter.

