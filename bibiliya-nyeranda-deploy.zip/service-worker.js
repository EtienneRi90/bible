const CACHE_NAME = 'bibiliya-nyeranda-v16';

// Core files needed for the app shell and the default language (Kirundi) to work
// fully offline right away. French and English are deliberately NOT precached here
// -- index.html now fetches them lazily, only once someone actually switches to
// that language, so a Kirundi-only reader never downloads the other two languages
// in the background. The fetch handler below still caches them (cache-first,
// same as everything else same-origin) the first time they're actually requested,
// so a language becomes available offline from then on, same as before.
const PRECACHE_URLS = [
  './',
  './index.html',
  './manifest.json',
  './bible-data.json',
  './icon-192.png',
  './icon-512.png'
];

// Cloudflare Pages (and some other static hosts) redirect /index.html -> / and
// /page.html -> /page. If we cache the response from a fetch that followed such
// a redirect, that cache entry keeps response.redirected === true. Handing a
// redirected response back to a top-level navigation later throws
// net::ERR_FAILED -- a real Chrome restriction, not a hosting bug. Stripping the
// flag by rebuilding a plain Response (same body/status/headers) avoids this
// wherever we cache anything.
async function cachePlain(cache, request, response) {
  if (!response || !response.ok) return response;
  if (!response.redirected) {
    cache.put(request, response.clone());
    return response;
  }
  const body = await response.clone().blob();
  const plain = new Response(body, {
    status: response.status,
    statusText: response.statusText,
    headers: response.headers
  });
  cache.put(request, plain.clone());
  return response;
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      await Promise.all(PRECACHE_URLS.map(async (url) => {
        const response = await fetch(url);
        await cachePlain(cache, url, response);
      }));
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Only handle GET requests
  if (event.request.method !== 'GET') return;

  // Top-level page loads (typing the URL, opening a bookmark, etc.) always resolve
  // to the same cached app shell, sidestepping the redirect issue described above.
  if (event.request.mode === 'navigate') {
    event.respondWith(
      caches.match('./index.html').then((cached) => {
        if (cached) return cached;
        return caches.open(CACHE_NAME).then(async (cache) => {
          const response = await fetch('./index.html');
          return cachePlain(cache, './index.html', response);
        }).catch(() => caches.match('./'));
      })
    );
    return;
  }

  const isSameOrigin = url.origin === self.location.origin;

  if (isSameOrigin) {
    // App shell and bundled Bible data: cache-first, so the app opens instantly
    // and works fully offline once visited once.
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;
        return caches.open(CACHE_NAME).then(async (cache) => {
          const response = await fetch(event.request);
          return cachePlain(cache, event.request, response);
        });
      })
    );
  } else {
    // English (thedouayrheims.com) and anything else external: network-first,
    // falling back to cache when offline. Successful responses are cached so
    // a book read once in English becomes available offline afterward too.
    event.respondWith(
      fetch(event.request)
        .then((response) => caches.open(CACHE_NAME).then((cache) => cachePlain(cache, event.request, response)))
        .catch(() => caches.match(event.request))
    );
  }
});
